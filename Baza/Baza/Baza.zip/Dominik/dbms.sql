SET SERVEROUTPUT ON;

-- now should this works:
dbms_output.put_line('...');
 